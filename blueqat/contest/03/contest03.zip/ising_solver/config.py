import os

THIS_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
DATA_DIRECTORY = os.path.abspath(
    os.path.join(THIS_DIRECTORY, 'diatomic')
)
